function test(){
    window.alert("별도로 작성된 js파일!!");
}